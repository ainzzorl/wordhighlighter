///<reference path="common/dao.ts" />
///<reference path="common/logger.ts" />
/**
 * Implements background logic: https://developer.mozilla.org/en-US/Add-ons/WebExtensions/Anatomy_of_a_WebExtension#Background_scripts
 */
var Background = /** @class */ (function () {
    function Background(dao) {
        this.dao = dao;
    }
    Background.prototype.start = function () {
        this.dao.init();
    };
    // TODO: use utility method to check for dupes
    Background.prototype.addWord = function (value) {
        var dao = this.dao;
        dao.getDictionary(function (dictionary) {
            var isDupe = dictionary
                .filter(function (entry) {
                return entry.value === value;
            }).length > 0;
            if (!isDupe) {
                dao.addEntry(value, '', false, function () {
                    WHLogger.log('Word ' + value + ' has been added to the dictionary through the context menu');
                });
            }
        });
    };
    return Background;
}());

///<reference path="./dom/highlightInjector.ts" />
///<reference path="./dom/domTraversal.ts" />
///<reference path="./dom/pageStatsInfoGenerator.ts" />
///<reference path="./matching/matchFinder.ts" />
///<reference path="common/dao.ts" />
///<reference path="common/logger.ts" />
///<reference path="common/settings.ts" />
///<reference path="highlightingLog/highlightingLog.ts" />
///<reference path="highlightingLog/highlightingLogEntry.ts" />
///<reference path="pageStats/pageStats.ts" />
/**
 * Implements content script logic: https://developer.mozilla.org/en-US/Add-ons/WebExtensions/Anatomy_of_a_WebExtension#Content_scripts
 */
var Content = /** @class */ (function () {
    function Content(dao, settings, highlightInjector, matchFinder, highlightingLog) {
        this.domTraversal = new DomTraversal();
        this.pageStatsInfoGenerator = new PageStatsInfoGenerator();
        this.pageStats = new PageStats();
        this.dao = dao;
        this.settings = settings;
        this.highlightInjector = highlightInjector;
        this.matchFinder = matchFinder;
        this.highlightingLog = highlightingLog;
    }
    Content.prototype.processDocument = function (doc) {
        if (!this.settings.enableHighlighting) {
            return;
        }
        this.startTime = performance.now();
        this.matchFinder.buildIndexes();
        var content = this;
        this.domTraversal.traverseEligibleTextNodes(doc, function (node) {
            content.onFound(content, node);
        }, function () {
            content.onFinished(content, doc);
        });
    };
    Content.prototype.isTimeout = function () {
        var now = performance.now();
        var seconds = (now - this.startTime) / 1000;
        return seconds > this.settings.timeout;
    };
    Content.prototype.onFound = function (content, node) {
        var _this = this;
        if (content.isTimeout()) {
            WHLogger.log('Terminating because of the timeout');
            content.domTraversal.stop();
            return;
        }
        var matches = content.matchFinder.findMatches(node.textContent);
        content.highlightInjector.inject(node, matches);
        matches
            .filter(function (match) { return match.matchOf; })
            .forEach(function (match) { return _this.pageStats.registerMatch(match.matchOf); });
    };
    Content.prototype.onFinished = function (content, doc) {
        if (content.pageStats.totalAppearances > 0) {
            if (content.settings.enablePageStats) {
                this.injectPageStatsInfo(content, doc);
                this.addEventListeners(doc);
            }
            this.highlightingLog.log(content.pageStats);
            this.dao.saveHighlightingLog(this.highlightingLog, function () { });
        }
        this.matchFinder.cleanup();
    };
    Content.prototype.injectPageStatsInfo = function (content, doc) {
        // Injecting the stats to the body.
        // Can't simply use doc.body because documents used in unit tests are XML, not HTML,
        // and they don't have body.
        // The reason they are XML is that DOMParser doesn't seem to support HTML in PhantomJS.
        var bodyNodes = doc.getElementsByTagName('body');
        for (var i = 0; i < bodyNodes.length; ++i) {
            bodyNodes[i].appendChild(content.pageStatsInfoGenerator.generate(content.pageStats));
        }
    };
    // TODO: unit test
    Content.prototype.addEventListeners = function (doc) {
        var _this = this;
        for (var _i = 0, _a = doc.querySelectorAll('#word-highlighter-page-stats a'); _i < _a.length; _i++) {
            var element = _a[_i];
            element.addEventListener('click', function () { _this.expandPageStats(doc); }, true);
        }
        doc.getElementById('word-highlighter-page-stats-close').addEventListener('click', function () {
            _this.dismissPageStats(doc);
        });
    };
    Content.prototype.expandPageStats = function (doc) {
        doc.getElementById('word-highlighter-per-word-stats').style.display = 'block';
    };
    Content.prototype.dismissPageStats = function (doc) {
        doc.getElementById('word-highlighter-page-stats').style.display = 'none';
    };
    return Content;
}());

///<reference path="../../../node_modules/@types/chrome/index.d.ts" />
///<reference path="dictionaryEntry.ts" />
///<reference path="logger.ts" />
///<reference path="settings.ts" />
///<reference path="../highlightingLog/highlightingLog.ts" />
///<reference path="../highlightingLog/highlightingLogEntry.ts" />
/**
 * Data Access Object.
 * Handles all interactions with the storage.
 */
var DAO = /** @class */ (function () {
    function DAO(_store) {
        if (_store === void 0) { _store = undefined; }
        this.store = _store || chrome.storage.local;
    }
    DAO.prototype.init = function () {
        this.initDictionary();
        this.initIdSequence();
        this.initSettings();
        this.initHighlightingLog();
    };
    DAO.prototype.getDictionary = function (callback) {
        var self = this;
        self.store.get(DAO.KEYS.dictionary, function (result) {
            callback(self.deserializeDictionary(result.dictionary));
        });
    };
    DAO.prototype.getSettings = function (callback) {
        var self = this;
        self.store.get(DAO.KEYS.settings, function (result) {
            callback(self.deserializeSettings(result.settings));
        });
    };
    DAO.prototype.getHighlightingLog = function (callback) {
        var self = this;
        self.store.get(DAO.KEYS.highlightingLog, function (result) {
            callback(self.deserializeHighlightingLog(result.highlightingLog));
        });
    };
    DAO.prototype.addEntry = function (value, description, strictMatch, callback) {
        var self = this;
        self.store.get([DAO.KEYS.dictionary, DAO.KEYS.idSequenceNumber], function (result) {
            var dictionary = self.deserializeDictionary(result.dictionary);
            var now = new Date();
            var entry = new DictionaryEntry(result.idSequenceNumber, value, description, now, now, strictMatch);
            dictionary.push(entry);
            self.store.set({ dictionary: self.serializeDictionary(dictionary), idSequenceNumber: result.idSequenceNumber + 1 }, function () {
                WHLogger.log('Word ' + entry.value + ' has been added to the storages');
                callback(self.serializeDictionaryEntry(entry));
            });
        });
    };
    DAO.prototype.saveDictionary = function (dictionary, callback) {
        var self = this;
        var entriesWithNoIds = dictionary.filter(function (dictionaryEntry) {
            return !dictionaryEntry.id;
        });
        if (entriesWithNoIds.length === 0) {
            self.store.set({ dictionary: self.serializeDictionary(dictionary) }, function () {
                WHLogger.log('Saved dictionary');
                callback();
            });
            return;
        }
        self.store.get(DAO.KEYS.idSequenceNumber, function (result) {
            var idSequenceNumber = result.idSequenceNumber;
            entriesWithNoIds.forEach(function (dictionaryEntry) {
                dictionaryEntry.id = idSequenceNumber++;
            });
            self.store.set({ idSequenceNumber: idSequenceNumber, dictionary: self.serializeDictionary(dictionary) }, function () {
                WHLogger.log('Saved the dictionary. New id sequence number: ' + idSequenceNumber);
                callback();
            });
        });
    };
    DAO.prototype.saveSettings = function (settings, callback) {
        this.store.set({ settings: this.serializeSettings(settings) }, function () {
            WHLogger.log('Saved the settings');
            callback();
        });
    };
    DAO.prototype.saveHighlightingLog = function (highlightingLog, callback) {
        this.store.set({ highlightingLog: this.serializeHighlightingLog(highlightingLog) }, function () {
            WHLogger.log('Saved the highlighting log');
            callback();
        });
    };
    DAO.prototype.initDictionary = function () {
        var self = this;
        self.store.get(DAO.KEYS.dictionary, function (result) {
            if (!result.dictionary) {
                self.store.set({ dictionary: [] }, function () {
                    WHLogger.log('Initialized the dictionary');
                });
            }
        });
    };
    DAO.prototype.initSettings = function () {
        var self = this;
        self.store.get(DAO.KEYS.settings, function (result) {
            if (!result.settings) {
                var settings = Settings.DEFAULT;
                self.store.set({ settings: self.serializeSettings(settings) }, function () {
                    WHLogger.log('Initialized the settings');
                });
            }
        });
    };
    DAO.prototype.initIdSequence = function () {
        var self = this;
        self.store.get(DAO.KEYS.idSequenceNumber, function (result) {
            if (!result.idSequenceNumber) {
                self.store.set({ idSequenceNumber: 1 }, function () {
                    WHLogger.log('Initialized the id sequence');
                });
            }
        });
    };
    DAO.prototype.initHighlightingLog = function () {
        var self = this;
        self.store.get(DAO.KEYS.highlightingLog, function (result) {
            if (!result.highlightingLog) {
                self.store.set({ highlightingLog: self.serializeHighlightingLog(new HighlightingLog()) }, function () {
                    WHLogger.log('Initialized the highlighting log');
                });
            }
        });
    };
    DAO.prototype.deserializeDictionary = function (input) {
        if (input === null) {
            return null;
        }
        return input.map(this.deserializeDictionaryEntry);
    };
    DAO.prototype.deserializeDictionaryEntry = function (input) {
        return new DictionaryEntry(input['id'], input['value'], input['description'], input['createdAt'], input['updatedAt'], input['strictMatch']);
    };
    DAO.prototype.deserializeHighlightingLog = function (input) {
        return new HighlightingLog(input.map(this.deserializeHighlightingLogEntry));
    };
    DAO.prototype.deserializeHighlightingLogEntry = function (input) {
        return new HighlightingLogEntry(input['url'], new Date(input['date']), input['highlights'].reduce(function (result, h) {
            result[h[0]] = h[1];
            return result;
        }, {}));
    };
    DAO.prototype.deserializeSettings = function (input) {
        var settings = new Settings();
        settings.timeout = input.timeout;
        settings.enableHighlighting = input.enableHighlighting;
        if (input.enablePageStats === undefined) {
            // Was created before stats was implemented.
            input.enablePageStats = Settings.DEFAULT_ENABLE_PAGE_STATS;
        }
        settings.enablePageStats = input.enablePageStats;
        return settings;
    };
    DAO.prototype.serializeDictionary = function (input) {
        if (input === null) {
            return null;
        }
        return input.map(this.serializeDictionaryEntry);
    };
    DAO.prototype.serializeDictionaryEntry = function (input) {
        return {
            id: input.id,
            value: input.value,
            description: input.description,
            createdAt: input.createdAt,
            updatedAt: input.updatedAt,
            strictMatch: input.strictMatch
        };
    };
    DAO.prototype.serializeSettings = function (input) {
        return {
            timeout: input.timeout,
            enableHighlighting: input.enableHighlighting,
            enablePageStats: input.enablePageStats
        };
    };
    DAO.prototype.serializeHighlightingLog = function (input) {
        return input.entries.map(this.serializeHighlightingLogEntry);
    };
    DAO.prototype.serializeHighlightingLogEntry = function (input) {
        return {
            url: input.url,
            date: input.date.getTime(),
            highlights: Object.keys(input.highlights).map(function (k) { return [k, input.highlights[k]]; })
        };
    };
    DAO.KEYS = {
        dictionary: 'dictionary',
        settings: 'settings',
        idSequenceNumber: 'idSequenceNumber',
        highlightingLog: 'highlightingLog'
    };
    return DAO;
}());

/**
 * A persistent entry in the dictionary.
 */
var DictionaryEntry = /** @class */ (function () {
    function DictionaryEntry(id, value, description, createdAt, updatedAt, strictMatch) {
        if (createdAt === void 0) { createdAt = undefined; }
        if (updatedAt === void 0) { updatedAt = undefined; }
        if (strictMatch === void 0) { strictMatch = false; }
        this._id = id;
        this._value = value;
        this._description = description;
        this._strictMatch = strictMatch;
        var now = new Date();
        this._createdAt = createdAt || now;
        this._updatedAt = updatedAt || now;
    }
    Object.defineProperty(DictionaryEntry.prototype, "id", {
        get: function () {
            return this._id;
        },
        set: function (_id) {
            this._id = _id;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DictionaryEntry.prototype, "value", {
        get: function () {
            return this._value;
        },
        set: function (_value) {
            this._value = _value;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DictionaryEntry.prototype, "description", {
        get: function () {
            return this._description;
        },
        set: function (_description) {
            this._description = _description;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DictionaryEntry.prototype, "createdAt", {
        get: function () {
            return this._createdAt;
        },
        set: function (_createdAt) {
            this._createdAt = _createdAt;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DictionaryEntry.prototype, "updatedAt", {
        get: function () {
            return this._updatedAt;
        },
        set: function (_updatedAt) {
            this._updatedAt = _updatedAt;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DictionaryEntry.prototype, "strictMatch", {
        get: function () {
            return this._strictMatch;
        },
        set: function (_strictMatch) {
            this._strictMatch = _strictMatch;
        },
        enumerable: true,
        configurable: true
    });
    DictionaryEntry.prototype.touch = function () {
        this._updatedAt = new Date();
    };
    return DictionaryEntry;
}());

/**
 * Logger.
 * Does nothing by default.
 * Set debug=true to see the logs.
 */
var WHLogger = /** @class */ (function () {
    function WHLogger() {
    }
    WHLogger.log = function (message) {
        if (this.debug) {
            console.log(message);
        }
    };
    WHLogger.debug = false;
    return WHLogger;
}());

/**
 * Settings.
 */
var Settings = /** @class */ (function () {
    function Settings(_timeout, _enableHighlighting, _enablePageStats) {
        if (_timeout === void 0) { _timeout = undefined; }
        if (_enableHighlighting === void 0) { _enableHighlighting = undefined; }
        if (_enablePageStats === void 0) { _enablePageStats = undefined; }
        this._timeout = _timeout;
        this._enableHighlighting = _enableHighlighting;
        this._enablePageStats = _enablePageStats;
    }
    Object.defineProperty(Settings.prototype, "timeout", {
        get: function () {
            return this._timeout;
        },
        set: function (_timeout) {
            this._timeout = _timeout;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Settings.prototype, "enableHighlighting", {
        get: function () {
            return this._enableHighlighting;
        },
        set: function (_enableHighlighting) {
            this._enableHighlighting = _enableHighlighting;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Settings.prototype, "enablePageStats", {
        get: function () {
            return this._enablePageStats;
        },
        set: function (_enablePageStats) {
            this._enablePageStats = _enablePageStats;
        },
        enumerable: true,
        configurable: true
    });
    Settings.DEFAULT_TIMEOUT = 3;
    Settings.DEFAULT_ENABLE_HIGHLIGHTING = true;
    Settings.DEFAULT_ENABLE_PAGE_STATS = true;
    Settings.DEFAULT = new Settings(Settings.DEFAULT_TIMEOUT, Settings.DEFAULT_ENABLE_HIGHLIGHTING, Settings.DEFAULT_ENABLE_PAGE_STATS);
    return Settings;
}());

/**
 * Class responsible for traversing DOM objects and finding text nodes eligible for highlight injection.
 */
var DomTraversal = /** @class */ (function () {
    function DomTraversal() {
        this.stopped = false;
        this.BLACKLISTED_TAGS = {
            'SCRIPT': true,
            'NOSCRIPT': true,
            'STYLE': true,
            'TITLE': true
        };
    }
    /**
     * Find text nodes eligible for injecting markup.
     * @param root The root node.
     * @param onFound Callback called when an eligible node is found.
     * @param onFinished Callback called once the traversal has finished.
     */
    DomTraversal.prototype.traverseEligibleTextNodes = function (root, onFound, onFinished) {
        this.traverse(root, onFound);
        onFinished();
    };
    /**
     * Stops the traversal.
     * Called when it's out of allocated time.
     */
    DomTraversal.prototype.stop = function () {
        this.stopped = true;
    };
    DomTraversal.prototype.traverse = function (node, onFound) {
        if (this.stopped || this.isBlacklisted(node)) {
            return;
        }
        var child = node.firstChild;
        while (child) {
            if (child.nodeType === Node.TEXT_NODE) {
                var textNode = child;
                if (textNode.textContent.trim().length > 0) {
                    onFound(textNode);
                }
            }
            else {
                this.traverse(child, onFound);
            }
            child = child.nextSibling;
        }
    };
    DomTraversal.prototype.isBlacklisted = function (node) {
        var tagName = node.tagName;
        return tagName && this.BLACKLISTED_TAGS[tagName.toUpperCase()];
    };
    return DomTraversal;
}());

///<reference path="../common/dictionaryEntry.ts" />
/**
 * Class responsible for generating highlights for a word.
 */
var HighlightGenerator = /** @class */ (function () {
    function HighlightGenerator() {
    }
    /**
     * Generate a chunk of HTML highlighting the word.
     * @param word Word that needs to be highlighted.
     * @param dictionaryEntry Dictionary entry matching the word.
     */
    HighlightGenerator.prototype.generate = function (word, dictionaryEntry) {
        return "<span class=\"highlighted-word\">" + word + this.tooltipContent(dictionaryEntry) + "</span>";
    };
    HighlightGenerator.prototype.tooltipContent = function (entry) {
        var wrappedDescription = entry.description ?
            "<div class=\"highlighted-word-description\">" + entry.description + "</div>" : '';
        var wordClass = entry.description ? '' : 'highlighted-word-title-no-description';
        return "<div class=\"highlighted-word-tooltip-wrapper\">\n                    <div class=\"highlighted-word-tooltip\">\n                        <p class=\"" + wordClass + "\">" + entry.value + "</p>\n                        " + wrappedDescription + "\n                    </div>\n                </div>";
    };
    return HighlightGenerator;
}());

///<reference path="./highlightGenerator.ts" />
///<reference path="../matching/matchResultEntry.ts" />
var HighlightInjectorImpl = /** @class */ (function () {
    function HighlightInjectorImpl(highlightGenerator) {
        this.highlightGenerator = highlightGenerator;
    }
    HighlightInjectorImpl.prototype.inject = function (textNode, matchResults) {
        if (matchResults.length === 1 && !matchResults[0].matchOf) {
            // No matches. Nothing will change if we don't exit here,
            // but it's likely to be much slower.
            return;
        }
        var replacementNodes = this.getReplacementNodes(matchResults);
        for (var i = 0; i < replacementNodes.length; ++i) {
            textNode.parentNode.insertBefore(replacementNodes[i], textNode);
        }
        textNode.parentNode.removeChild(textNode);
    };
    HighlightInjectorImpl.prototype.getReplacementNodes = function (matchResults) {
        var html = '';
        for (var i = 0; i < matchResults.length; ++i) {
            if (matchResults[i].matchOf) {
                html += this.highlightGenerator.generate(matchResults[i].value, matchResults[i].matchOf);
            }
            else {
                html += matchResults[i].value;
            }
        }
        var newNode = document.createElement('doesnotmatter');
        newNode.innerHTML = html;
        return Array.prototype.slice.call(newNode.childNodes);
    };
    return HighlightInjectorImpl;
}());

///<reference path="../common/dictionaryEntry.ts" />
///<reference path="../pageStats/pageStats.ts" />
/**
 * Class responsible for generating page stats info (displayed in the right bottom corner).
 *
 * There's no spec for this class: it's pure presentation. It is tested by end-to-end tests.
 */
var PageStatsInfoGenerator = /** @class */ (function () {
    function PageStatsInfoGenerator() {
    }
    /**
     * Generate HTML showing stats about words found on the page.
     * @param stats Page stats.
     */
    PageStatsInfoGenerator.prototype.generate = function (stats) {
        var html = "<div id=\"word-highlighter-page-stats\">\n                        " + this.generateCloseButton() + "\n                        " + this.generateAggregates(stats) + "\n                        " + this.generatePerWordDetails(stats) + "\n                        " + this.generateTip() + "\n                    </div>";
        var result = document.createElement('div');
        result.innerHTML = html;
        return result;
    };
    PageStatsInfoGenerator.prototype.generatePerWordDetails = function (stats) {
        return '<div id="word-highlighter-per-word-stats">'
            + stats.wordAppearanceStats
                .sort(function (a1, a2) { return a2.count - a1.count; })
                .reduce(function (acc, wordStats) {
                var res = acc
                    + ("<div>\n                                <div class=\"word-highlighter-per-word-stats-value\">" + wordStats.dictionaryEntry.value + "</div>\n                                <div class=\"word-highlighter-per-word-stats-count\">" + wordStats.count + "</div>\n                               </div>");
                return res;
            }, '')
            + '</div>';
    };
    PageStatsInfoGenerator.prototype.generateAggregates = function (stats) {
        return "<div>\n                    <p class=\"word-highlighter-page-stats-header\">\n                        Highlighted\n                    </p>\n                    <p>\n                        <a>\n                            <span class=\"word-highlighter-stats-aggregate\">\n                                " + stats.totalAppearedWords + "\n                            </span>\n                            words\n                        </a>\n                    </p>\n                    <p>\n                        <a>\n                            <span class=\"word-highlighter-stats-aggregate\">\n                                " + stats.totalAppearances + "\n                            </span>\n                            times\n                        </a>\n                    </p>\n                </div>";
    };
    PageStatsInfoGenerator.prototype.generateCloseButton = function () {
        return '<span id="word-highlighter-page-stats-close">x</span>';
    };
    // Encourage users who find the popup annoying to disable the feature rather than uninstall the plugin altogether.
    PageStatsInfoGenerator.prototype.generateTip = function () {
        return '<div id="word-highlighter-page-stats-tip">Tip: you can disable this popup in settings.</div>';
    };
    return PageStatsInfoGenerator;
}());

///<reference path="highlightingLogEntry.ts" />
///<reference path="../pageStats/pageStats.ts" />
/**
 * Log of highlights. Powers "History" tab.
 * One entry = 1 page load with highlights.
 */
var HighlightingLog = /** @class */ (function () {
    function HighlightingLog(entries) {
        if (entries === void 0) { entries = []; }
        // We limit the number of entries in the log
        // to reduce the risk of exceeding the storage limit.
        // It'd be better to evict entries only when it starts erroring out,
        // but it's also trickier because the error can happen when saving some other objects
        // such as dictionary or settings.
        this.LIMIT = 100 * 1000;
        this.entries = entries;
    }
    HighlightingLog.prototype.log = function (pageStats) {
        this.entries.push(new HighlightingLogEntry(window.location.href, new Date(), pageStats.counts));
        if (this.entries.length > this.LIMIT) {
            this.entries.shift();
        }
    };
    return HighlightingLog;
}());

/**
 * A persistent entry in the highlighting log.
 * Represents a single page load with highlights.
 */
var HighlightingLogEntry = /** @class */ (function () {
    function HighlightingLogEntry(url, date, highlights) {
        if (date === void 0) { date = new Date(); }
        if (highlights === void 0) { highlights = {}; }
        this.url = url;
        this.date = date;
        this.highlights = highlights;
    }
    return HighlightingLogEntry;
}());

///<reference path="stemmer.ts" />
///<reference path="matchResultEntry.ts" />
///<reference path="token.ts" />
///<reference path="../common/dictionaryEntry.ts" />
var MatchFinderImpl = /** @class */ (function () {
    function MatchFinderImpl(dictionary, stemmer) {
        this.IGNORED_PREFIXES = ['a ', 'an ', 'to '];
        this.dictionary = dictionary;
        this.stemmer = stemmer;
        this.contentWordStems = {};
    }
    // Detect words matching the dictionary in the input.
    MatchFinderImpl.prototype.findMatches = function (input) {
        var _this = this;
        var result = [];
        var currentNoMatch = '';
        this.tokenize(input).forEach(function (token) {
            if (!token.isWord) {
                currentNoMatch += token.value;
                return;
            }
            var match = _this.findMatchForWord(token.value);
            if (!match) {
                currentNoMatch += token.value;
                return;
            }
            _this.pushMatchIfNotEmpty(result, currentNoMatch, null);
            _this.pushMatchIfNotEmpty(result, token.value, match);
            currentNoMatch = '';
        });
        this.pushMatchIfNotEmpty(result, currentNoMatch, null);
        return result;
    };
    // Build indexes. Must be called before matching.
    // Not automatically calling from the constructor to prevent
    // unnecessary calculations when highlighting is disabled.
    MatchFinderImpl.prototype.buildIndexes = function () {
        this.dictionaryStemMap = {};
        this.strictMatchMap = {};
        if (!this.stemmer) {
            return;
        }
        for (var i = 0; i < this.dictionary.length; ++i) {
            var entry = this.dictionary[i];
            if (entry.strictMatch) {
                this.strictMatchMap[entry.value.toLowerCase()] = entry;
            }
            else {
                var stem = this.stemmer.stem(this.removeIgnoredPrefixes(entry.value));
                if (stem) {
                    this.dictionaryStemMap[stem] = entry;
                }
            }
        }
    };
    // Releasing memory.
    MatchFinderImpl.prototype.cleanup = function () {
        this.contentWordStems = {};
        this.dictionaryStemMap = {};
        this.strictMatchMap = {};
    };
    MatchFinderImpl.prototype.tokenize = function (input) {
        var result = [];
        var currentWord = '';
        var currentNonWord = '';
        for (var i = 0; i < input.length; ++i) {
            if (this.isWordCharacter(input[i])) {
                this.pushTokenIfNotEmpty(result, currentNonWord, false);
                currentNonWord = '';
                currentWord += input[i];
            }
            else {
                this.pushTokenIfNotEmpty(result, currentWord, true);
                currentWord = '';
                currentNonWord += input[i];
            }
        }
        this.pushTokenIfNotEmpty(result, currentNonWord, false);
        this.pushTokenIfNotEmpty(result, currentWord, true);
        return result;
    };
    MatchFinderImpl.prototype.findMatchForWord = function (word) {
        var strictMatch = this.strictMatchMap[word.toLowerCase()];
        if (strictMatch && strictMatch.value) {
            return strictMatch;
        }
        var cachedStem = this.contentWordStems[word];
        var targetStem;
        if (cachedStem) {
            targetStem = cachedStem;
        }
        else {
            targetStem = this.stemmer.stem(word);
            this.contentWordStems[word] = targetStem;
        }
        var result = this.dictionaryStemMap[targetStem];
        return (result && result.value) ? result : null;
    };
    MatchFinderImpl.prototype.isWordCharacter = function (char) {
        return char[0] >= 'a' && char[0] <= 'z'
            || char[0] >= 'A' && char[0] <= 'Z'
            || char[0] >= '0' && char[0] <= '9';
    };
    MatchFinderImpl.prototype.removeIgnoredPrefixes = function (input) {
        var result = input;
        this.IGNORED_PREFIXES.forEach(function (prefix) {
            if (result.toLowerCase().lastIndexOf(prefix, 0) === 0) {
                result = result.substring(prefix.length);
            }
        });
        return result;
    };
    MatchFinderImpl.prototype.pushMatchIfNotEmpty = function (result, value, matchOf) {
        if (value.length > 0) {
            result.push({
                value: value,
                matchOf: matchOf
            });
        }
    };
    MatchFinderImpl.prototype.pushTokenIfNotEmpty = function (result, value, isWord) {
        if (value.length > 0) {
            result.push({
                value: value,
                isWord: isWord
            });
        }
    };
    return MatchFinderImpl;
}());

///<reference path="../common/dictionaryEntry.ts" />



///<reference path="../common/dictionaryEntry.ts" />
/**
 * Statistics about a page load.
 */
var PageStats = /** @class */ (function () {
    function PageStats() {
        // (dictionary entry id)->(number of appearances)
        this.counts = {};
        // Need 2 maps because DictionaryEntry can't be a key of a map.
        // (dictionary entry id)->(dictionaryEntry)
        this.entries = {};
        this.totalApparances = 0;
    }
    PageStats.prototype.registerMatch = function (dictionaryEntry) {
        var oldCount = this.counts[dictionaryEntry.id];
        if (oldCount) {
            this.counts[dictionaryEntry.id] = oldCount + 1;
        }
        else {
            this.counts[dictionaryEntry.id] = 1;
            this.entries[dictionaryEntry.id] = dictionaryEntry;
        }
        this.totalApparances++;
    };
    Object.defineProperty(PageStats.prototype, "wordAppearanceStats", {
        /**
         * Returns a list of (dictionary entry, number of appearances) stats.
         */
        get: function () {
            var counts = this.counts;
            var entries = this.entries;
            return Object.keys(this.entries)
                .map(function (id) {
                return {
                    count: counts[parseInt(id)],
                    dictionaryEntry: entries[parseInt(id)]
                };
            });
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PageStats.prototype, "totalAppearedWords", {
        /**
         * Total number of dictionary words appearing on the page.
         */
        get: function () {
            return Object.keys(this.entries).length;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PageStats.prototype, "totalAppearances", {
        /**
         * Total number number of dictionary word appearances on the page.
         */
        get: function () {
            return this.totalApparances;
        },
        enumerable: true,
        configurable: true
    });
    return PageStats;
}());

///<reference path="../common/dictionaryEntry.ts" />
