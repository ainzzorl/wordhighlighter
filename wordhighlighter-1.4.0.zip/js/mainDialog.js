///<reference path="../lib/common/dao.ts" />
///<reference path="../lib/common/logger.ts" />
var DEFAULT_TAB = 'words';
var app = angular.module('mainDialog', ['ngTable']);
app.service('dao', function () {
    return new DAO();
});
app
    .run(function ($rootScope) {
    $rootScope.currentTab = DEFAULT_TAB;
});
// The code below is an ugly workaround for a bug.
// For some reason, when any ng-tracked element is changed,
// the scroll position is automatically reset to the top.
// This happens in Firefox, but works normally in Chrome.
// This is an attempt to detect and block these abnormal scrolls.
// Of course, some "real" scrolls are blocked by it as well.
var currentXOffset = 0;
var currentYOffset = 0;
app
    .run(function ($window) {
    if ($window.navigator.userAgent.toLowerCase().indexOf('firefox') < 0) {
        return;
    }
    angular.element($window).bind('scroll', function () {
        if (this.pageYOffset === 0 && this.pageYOffset !== currentYOffset && currentYOffset > 10) {
            WHLogger.log('Strange scroll has been detected');
            $window.scrollTo(currentXOffset, currentYOffset);
            WHLogger.log('Reset scroll to ' + currentXOffset + ', ' + currentYOffset);
        }
        currentXOffset = this.pageXOffset;
        currentYOffset = this.pageYOffset;
    });
});

///<reference path="../lib/common/dao.ts" />
angular
    .module('mainDialog')
    .controller('historyController', function ($scope, NgTableParams, dao) {
    $scope.DEFAULT_INTERVAL_DAYS = 30;
    $scope.interval = {
        value: $scope.DEFAULT_INTERVAL_DAYS
    };
    $scope.MILLISECONDS_IN_DAY = 1000 * 3600 * 24;
    $scope.refresh = function () {
        $scope.isIntervalValid = !isNaN($scope.interval.value);
        if (!$scope.isIntervalValid) {
            return;
        }
        $scope.interval.value = Number($scope.interval.value);
        dao.getHighlightingLog(function (highlightingLog) {
            dao.getDictionary(function (dictionary) {
                $scope.tableData = populateTableData(dictionary, highlightingLog);
                $scope.tableParams = new NgTableParams({
                    sorting: { total: 'desc' },
                    count: 1000000000 // hide pager
                }, {
                    dataset: $scope.tableData,
                    counts: [] // hide page sizes
                });
                $scope.$apply();
            });
        });
    };
    function populateTableData(dictionary, highlightingLog) {
        var totals = {}; // dictionary entry id -> total highlight count.
        var pages = {}; // dictionary entry id -> url -> 1.
        var now = new Date();
        var _loop_1 = function (i) {
            var highlightingLogEntry = highlightingLog.entries[i];
            var daysAgo = (now.getTime() - highlightingLogEntry.date.getTime()) / $scope.MILLISECONDS_IN_DAY;
            if (daysAgo > $scope.interval.value) {
                return "break";
            }
            Object.keys(highlightingLogEntry.highlights).forEach(function (dictionaryEntryIdStr) {
                var dictionaryEntryId = Number(dictionaryEntryIdStr);
                var total = totals[dictionaryEntryId] || 0;
                totals[dictionaryEntryId] = total + highlightingLogEntry.highlights[dictionaryEntryId];
                var wordPages = pages[dictionaryEntryId] || {};
                wordPages[highlightingLogEntry.url] = 1;
                pages[dictionaryEntryId] = wordPages;
            });
        };
        for (var i = highlightingLog.entries.length - 1; i >= 0; i--) {
            var state_1 = _loop_1(i);
            if (state_1 === "break")
                break;
        }
        return dictionary.map(function (dictionaryEntry) {
            return {
                word: dictionaryEntry.value,
                total: totals[dictionaryEntry.id] || 0,
                uniquePages: pages[dictionaryEntry.id] ? Object.keys(pages[dictionaryEntry.id]).length : 0
            };
        });
    }
    $scope.refresh();
});

///<reference path="../lib/common/dao.ts" />
///<reference path="../lib/common/dictionaryEntry.ts" />
angular
    .module('mainDialog')
    .controller('importController', function ($scope, dao) {
    $scope.MODE_KEEP = 'keep';
    $scope.MODE_OVERWRITE = 'overwrite';
    $scope.MODE_REPLACE = 'replace';
    $scope.importInput = {
        data: '',
        mode: $scope.MODE_KEEP
    };
    $scope.showInputSuccessConfirmation = false;
    $scope.onImportClicked = function () {
        var input = $scope.parseInput();
        $scope.showInputSuccessConfirmation = false;
        $scope.dupes = $scope.getDuplicateEntries(input);
        if ($scope.dupes.length > 0) {
            return;
        }
        switch ($scope.importInput.mode) {
            case $scope.MODE_KEEP:
                $scope.importAndKeep(input);
                break;
            case $scope.MODE_REPLACE:
                $scope.importAsReplacement(input);
                break;
            case $scope.MODE_OVERWRITE:
                $scope.importAndOverwrite(input);
                break;
        }
    };
    $scope.parseInput = function () {
        var result = [];
        var lines = $scope.importInput.data.split('\n');
        lines.forEach(function (line) {
            line = line.trim();
            if (!line) {
                return;
            }
            var semicolumnIndex = line.indexOf(';');
            if (semicolumnIndex < 0) {
                result.push(new DictionaryEntry(null, line, '', new Date(), new Date()));
                return;
            }
            var word = line.substring(0, semicolumnIndex).trim();
            var description = line.substring(semicolumnIndex + 1).trim();
            result.push(new DictionaryEntry(null, word, description, new Date(), new Date()));
        });
        return result;
    };
    // Assumes that all words are trimmed already (should be done by parseInput)
    $scope.getDuplicateEntries = function (entries) {
        var result = [];
        var found = {};
        entries.forEach(function (entry) {
            var word = entry.value.toLowerCase();
            var pastCount = found[word];
            if (pastCount === 1) {
                result.push(entry.value);
                found[word] = pastCount + 1;
            }
            else {
                if (pastCount !== undefined) {
                    found[word] = pastCount + 1;
                }
                else {
                    found[word] = 1;
                }
            }
        });
        return result;
    };
    $scope.importAsReplacement = function (entries) {
        dao.saveDictionary(entries, onSuccess);
    };
    $scope.importAndKeep = function (newEntries) {
        dao.getDictionary(function (dictionary) {
            newEntries.forEach(function (newEntry) {
                var exists = dictionary.some(function (existingEntry) {
                    return existingEntry.value === newEntry.value;
                });
                if (!exists) {
                    dictionary.push(newEntry);
                }
            });
            dao.saveDictionary(dictionary, onSuccess);
        });
    };
    $scope.importAndOverwrite = function (newEntries) {
        dao.getDictionary(function (dictionary) {
            newEntries.forEach(function (newEntry) {
                var exists = false;
                dictionary.forEach(function (existingEntry) {
                    if (existingEntry.value === newEntry.value) {
                        exists = true;
                        existingEntry.description = newEntry.description;
                        existingEntry.updatedAt = newEntry.updatedAt;
                    }
                });
                if (!exists) {
                    dictionary.push(newEntry);
                }
            });
            dao.saveDictionary(dictionary, onSuccess);
        });
    };
    function onSuccess() {
        $scope.showInputSuccessConfirmation = true;
        $scope.importInput.data = '';
        $scope.$apply();
    }
});

///<reference path="../lib/common/dao.ts" />
angular
    .module('mainDialog')
    .controller('settingsController', function ($scope, $timeout, dao) {
    $scope.isSaving = false;
    $scope.load = function () {
        dao.getSettings(function (settings) {
            $scope.settings = settings;
            $scope.$apply();
        });
    };
    $scope.save = function () {
        $scope.isSaving = true;
        dao.saveSettings($scope.settings, function () {
            // Saving happens so fast that it's difficult to notice.
            // Keeping the spinner on a little longer
            // to let users see the spinner and assure the changes are saved.
            $timeout(function () {
                $scope.isSaving = false;
                $scope.$apply();
            }, 300);
        });
    };
    $scope.load();
});

// TODO: unit test
angular
    .module('mainDialog')
    .filter('toSafeHtml', ['$sce', function ($sce) {
        return function (text) {
            var result = text ? text.replace(/\n/g, '<br>') : '';
            return $sce.trustAsHtml(result);
        };
    }]);

///<reference path="../lib/common/dao.ts" />
///<reference path="../lib/common/dictionaryEntry.ts" />
angular
    .module('mainDialog')
    .controller('wordsController', function ($scope, NgTableParams, dao) {
    $scope.dictionary = [];
    $scope.newWord = {
        value: '',
        description: '',
        scrictMatch: false
    };
    $scope.showAddingDupeError = false;
    $scope.load = function () {
        dao.getDictionary(function (dictionary) {
            $scope.dictionary = dictionary;
            $scope.tableParams = new NgTableParams({
                count: 1000000000 // hide pager
            }, {
                dataset: $scope.dictionary,
                counts: [] // hide page sizes
            });
            $scope.originalData = angular.copy($scope.dictionary);
            $scope.$apply();
        });
    };
    $scope.onAddNewWordClicked = function () {
        var newValue = $scope.newWord.value.trim();
        if (newValue) {
            if ($scope.isDupe(newValue)) {
                $scope.showAddingDupeError = true;
                return;
            }
            dao.addEntry(newValue, $scope.newWord.description, $scope.newWord.strictMatch, function (newEntry) {
                $scope.dictionary.push(newEntry);
                $scope.tableParams.reload();
            });
            $scope.newWord.value = '';
            $scope.newWord.description = '';
            $scope.newWord.strictMatch = false;
            $scope.showAddingDupeError = false;
            $scope.newWordForm.$setPristine();
        }
    };
    $scope.cancel = function (dictionaryEntry, dictionaryEntryForm) {
        var originalRow = resetRow(dictionaryEntry, dictionaryEntryForm);
        angular.extend(dictionaryEntry, originalRow);
        dictionaryEntry.isDupe = false;
    };
    $scope.delete = function (dictionaryEntry) {
        $scope.dictionary.splice(findEntryIndexById(dictionaryEntry.id), 1);
        $scope.tableParams.reload();
        dao.saveDictionary($scope.dictionary, function () { });
    };
    $scope.save = function (dictionaryEntry, dictionaryEntryForm) {
        if ($scope.isDupe(dictionaryEntry.value, dictionaryEntry.id)) {
            dictionaryEntry.isDupe = true;
            return;
        }
        var originalRow = resetRow(dictionaryEntry, dictionaryEntryForm);
        if (changed(dictionaryEntry, originalRow)) {
            dictionaryEntry.touch();
            dao.saveDictionary($scope.dictionary, function () { });
        }
        angular.extend(originalRow, dictionaryEntry);
        dictionaryEntry.isDupe = false;
    };
    $scope.isDupe = function (word, skippedId) {
        if (skippedId === void 0) { skippedId = undefined; }
        for (var i = 0; i < $scope.dictionary.length; ++i) {
            if ($scope.dictionary[i].value && $scope.dictionary[i].value.toUpperCase() === word.toUpperCase()
                && (!skippedId || skippedId !== $scope.dictionary[i].id)) {
                return true;
            }
        }
        return false;
    };
    var resetRow = function (dictionaryEntry, dictionaryEntryForm) {
        dictionaryEntry.isEditing = false;
        dictionaryEntry.isDeleting = false;
        dictionaryEntryForm.$setPristine();
        for (var i = 0; i < $scope.originalData.length; ++i) {
            if ($scope.originalData[i].id === dictionaryEntry.id) {
                return $scope.originalData[i];
            }
        }
        return null;
    };
    function findEntryIndexById(id) {
        for (var i = 0; i < $scope.dictionary.length; ++i) {
            if ($scope.dictionary[i].id === id) {
                return i;
            }
        }
        return -1;
    }
    function changed(dictionaryEntry, originalRow) {
        return dictionaryEntry.value !== originalRow.value
            || dictionaryEntry.description !== originalRow.description
            || dictionaryEntry.strictMatch !== originalRow.strictMatch;
    }
    $scope.load();
});
