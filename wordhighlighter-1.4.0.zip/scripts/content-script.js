///<reference path="../lib/content.ts" />
///<reference path="../lib/common/dao.ts" />
///<reference path="../lib/common/logger.ts" />
// Content script: https://developer.mozilla.org/en-US/Add-ons/WebExtensions/Anatomy_of_a_WebExtension#Content_scripts
var timeStart = performance.now();
WHLogger.log('Processing URL ' + document.URL);
new DAO().getDictionary(function (dictionary) {
    new DAO().getSettings(function (settings) {
        new DAO().getHighlightingLog(function (highlightingLog) {
            // "stemmer" is not in Window class,
            // so we need to convert the object to "any" to read the property.
            var wnd = window;
            var stemmer = wnd.stemmer;
            var dao = new DAO();
            var highlightInjector = new HighlightInjectorImpl(new HighlightGenerator());
            var matchFinder = new MatchFinderImpl(dictionary, stemmer);
            var content = new Content(dao, settings, highlightInjector, matchFinder, highlightingLog);
            content.processDocument(document);
            var timeEnd = performance.now();
            var seconds = (timeEnd - timeStart) / 1000;
            WHLogger.log('Finished processing ' + document.URL + ' in ' + seconds.toFixed(2) + ' seconds');
        });
    });
});
